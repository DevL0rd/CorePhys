﻿Module Physics
    Private Gravity As New Point(0, 0)
    Private DeltaTime As Integer = 5000

End Module
