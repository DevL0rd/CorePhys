﻿Option Strict Off
Module IO
    Public Memory As New Dictionary(Of String, Dictionary(Of String, List(Of List(Of String))))
    Public BIN As String = Application.StartupPath & "\BIN\"
    Private Declare Unicode Function WritePrivateProfileString Lib "kernel32" _
    Alias "WritePrivateProfileStringW" (ByVal lpApplicationName As String,
    ByVal lpKeyName As String, ByVal lpString As String,
    ByVal lpFileName As String) As Integer

    Private Declare Unicode Function GetPrivateProfileString Lib "kernel32" _
    Alias "GetPrivateProfileStringW" (ByVal lpApplicationName As String,
    ByVal lpKeyName As String, ByVal lpDefault As String,
    ByVal lpReturnedString As String, ByVal nSize As Integer,
    ByVal lpFileName As String) As Integer
    'The function Readini and write ini are store, the function fomat is as follows
    'Readini(FileLocation, Section, ValueName, "")
    'Writeini(FileLocation, Section, ValueName, NewValue)
    Public Sub writeIni(ByVal iniFileName As String, ByVal Section As String, ByVal ParamName As String, ByVal ParamVal As String)
        If Not System.IO.Directory.Exists(BIN) Then
            System.IO.Directory.CreateDirectory(BIN)
        End If
        ParamVal = ParamVal.Replace(vbNewLine, "<NEW_LINE>")
        Dim Result As Integer = WritePrivateProfileString(Section, ParamName, ParamVal, iniFileName)
    End Sub

    Public Function ReadIni(ByVal IniFileName As String, ByVal Section As String, ByVal ParamName As String, ByVal ParamDefault As String) As String
        ReadIni = ""
        Try
            If System.IO.File.Exists(IniFileName) Then
                Dim ParamVal As String = Space$(1024)
                Dim LenParamVal As Long = GetPrivateProfileString(Section, ParamName, ParamDefault, ParamVal, Len(ParamVal), IniFileName)
                ReadIni = Left$(ParamVal, LenParamVal)
                ReadIni = ReadIni.Replace("<NEW_LINE>", vbNewLine)
            End If
        Catch ex As Exception
            Console.WriteLine("ERROR--" & "[" & ex.ToString & "]")
        End Try
        Return ReadIni
    End Function
    Public Function Load(File As String) As Boolean
        'Filename>NodeName>ObjectNames>Values(List)
        Dim Had_Error As Boolean = False
        Dim FileName As String = File
        File = BIN & File
        Dim FileIndex As Integer = Convert.ToInt32(ReadIni(File, "FileInfo", "FileIndex", ""))
        Dim Node As New Dictionary(Of String, List(Of List(Of String)))
        On Error GoTo HadError
        Do Until FileIndex <= 0
            Dim NodeName As String = ReadIni(File, "Node-" & FileIndex, "Node", "")
            Dim NodeIndex As Integer = Convert.ToInt32(ReadIni(File, "Node-" & FileIndex, "NodeIndex", ""))
            Dim Objects As New List(Of List(Of String))
            Do Until NodeIndex <= 0
                Dim Vals As New List(Of String)
                Dim values As String() = Nothing
                values = ReadIni(File, "Node-" & FileIndex, "Val-" & NodeIndex, "").Split("*")
                Dim s As String
                For Each s In values
                    Vals.Add(s)
                Next
                Objects.Add(Vals)
                NodeIndex -= 1
            Loop
            Node.Add(NodeName, Objects)
                FileIndex -= 1
            Loop
        Memory.Add(FileName, Node)
        Return True
        Exit Function
HadError:
        Return False
    End Function
    Public Sub UnloadFile(File As String)

    End Sub
    Public Function Save(File As String) As Boolean

    End Function

End Module
