﻿Public Class Form1
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If IO.Load("Test.CP") Then
            EngineLoop()
        End If
    End Sub
    Public Sub GameEvents()

    End Sub

    Public Sub AI()
        Dim rectcount As Integer = Memory.Item("Test.CP").Item("Rectangles").Count - 1
        While rectcount >= 0
            Dim name As String = Memory.Item("Test.CP").Item("Rectangles").Item(rectcount).Item(0)
            Dim x As Integer = Memory.Item("Test.CP").Item("Rectangles").Item(rectcount).Item(1)
            Dim y As Integer = Memory.Item("Test.CP").Item("Rectangles").Item(rectcount).Item(2)
            Dim w As Integer = Memory.Item("Test.CP").Item("Rectangles").Item(rectcount).Item(3)
            Dim h As Integer = Memory.Item("Test.CP").Item("Rectangles").Item(rectcount).Item(4)
            Dim texture As String = Memory.Item("Test.CP").Item("Rectangles").Item(rectcount).Item(5)
            Dim status As String = Memory.Item("Test.CP").Item("Rectangles").Item(rectcount).Item(6)
            Dim type As String = Memory.Item("Test.CP").Item("Rectangles").Item(rectcount).Item(11)
            If type = "follow" Then
            ElseIf type = "avoid" Then
            ElseIf type = "random" Then
            ElseIf type = "enemy" Then
            ElseIf type = "passive" Then
            Else

            End If
            Memory.Item("Test.CP").Item("Rectangles").Item(rectcount).Item(1) = x
            Memory.Item("Test.CP").Item("Rectangles").Item(rectcount).Item(2) = y
            Memory.Item("Test.CP").Item("Rectangles").Item(rectcount).Item(3) = w
            Memory.Item("Test.CP").Item("Rectangles").Item(rectcount).Item(4) = h
            Memory.Item("Test.CP").Item("Rectangles").Item(rectcount).Item(6) = status
        End While
    End Sub
End Class
