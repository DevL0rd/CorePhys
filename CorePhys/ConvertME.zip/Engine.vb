﻿Imports System.Xml

Module Engine
    Private Textures As New Dictionary(Of String, Image)
    ' GRAPHICS VARIABLES
    Private G As Graphics
    Private BBG As Graphics
    Private BB As Bitmap
    ' FPS COUNTER
    Private tSec As Integer = TimeOfDay.Second
    Private tTicks As Integer = 0
    Public MaxTicks As Integer = 0
    Public IsRunning As Boolean = False
    Sub InitGraphics()
        ' INITIALIZE GRAPHICS OBJECTS
        G = Form1.CreateGraphics
        BB = New Bitmap(Form1.Width, Form1.Height)
    End Sub
    Public Sub EngineLoop()
        IsRunning = True
        InitGraphics()
        LoadAssets()
        Do While IsRunning = True
            Form1.GameEvents()
            Form1.AI()
            BufferGraphics()
            DrawGraphics()
            CountTick()
            Form1.Button1.Text = MaxTicks
            Application.DoEvents()
        Loop
    End Sub
    Sub AIs()

    End Sub
    Sub LoadAssets()
        If System.IO.Directory.Exists(BIN & "Textures\") Then
            System.IO.Directory.CreateDirectory(BIN & "Textures\")
            ' Make a reference to a directory.
            Dim di As New System.IO.DirectoryInfo(BIN & "Textures\")
            Dim fiArr As System.IO.FileInfo() = di.GetFiles()
            Dim fri As System.IO.FileInfo
            For Each fri In fiArr
                Textures.Add(fri.Name, Image.FromFile(fri.FullName))
            Next fri
        End If
    End Sub
    Sub BufferGraphics()
        'rect drawing
        Dim rectcount As Integer = Memory.Item("Test.CP").Item("Rectangles").Count - 1
        While rectcount >= 0
            Dim name As String = Memory.Item("Test.CP").Item("Rectangles").Item(rectcount).Item(0)
            Dim x As Integer = Memory.Item("Test.CP").Item("Rectangles").Item(rectcount).Item(1)
            Dim y As Integer = Memory.Item("Test.CP").Item("Rectangles").Item(rectcount).Item(2)
            Dim w As Integer = Memory.Item("Test.CP").Item("Rectangles").Item(rectcount).Item(3)
            Dim h As Integer = Memory.Item("Test.CP").Item("Rectangles").Item(rectcount).Item(4)
            If x + w > 0 AndAlso x < Form1.Width AndAlso y + h > 0 AndAlso y < Form1.Width Then
                Dim texture As String = Memory.Item("Test.CP").Item("Rectangles").Item(rectcount).Item(5)
                Dim status As String = Memory.Item("Test.CP").Item("Rectangles").Item(rectcount).Item(6)
                Dim frame As Integer = Memory.Item("Test.CP").Item("Rectangles").Item(rectcount).Item(7)
                Dim framedelay = Memory.Item("Test.CP").Item("Rectangles").Item(rectcount).Item(8)
                Dim nextframecountdown As Integer = Memory.Item("Test.CP").Item("Rectangles").Item(rectcount).Item(9)
                If nextframecountdown <= 0 Then
                    Memory.Item("Test.CP").Item("Rectangles").Item(rectcount).Item(7) = frame + 1
                    'MsgBox(name & "  nextframecountdown: " & Memory.Item("Test.CP").Item("Rectangles").Item(rectcount).Item(9) & "  framedelay:" & framedelay & "  frame:" & Memory.Item("Test.CP").Item("Rectangles").Item(rectcount).Item(7))
                    Memory.Item("Test.CP").Item("Rectangles").Item(rectcount).Item(9) = framedelay
                Else
                    Memory.Item("Test.CP").Item("Rectangles").Item(rectcount).Item(9) -= 1
                End If
                If Textures.ContainsKey(texture & "-" & status & "-" & frame & ".png") Then
                    G.DrawImage(Textures.Item(texture & "-" & status & "-" & frame & ".png"), New Rectangle(x, y, w, h))
                Else
                    Memory.Item("Test.CP").Item("Rectangles").Item(rectcount).Item(7) = 1
                    frame = 1
                    If Textures.ContainsKey(texture & "-" & status & "-" & frame & ".png") Then
                        G.DrawImage(Textures.Item(texture & "-" & status & "-" & frame & ".png"), New Rectangle(x, y, w, h))
                    Else
                        MsgBox("Missing texture for rect: " & name & "   ID:" & rectcount)
                        'the image doesn't exist
                    End If
                End If
            End If
            rectcount -= 1
        End While
    End Sub
    Sub DrawGraphics()
        ' DRAW BUFFER TO SCREEN
        G = Graphics.FromImage(BB)
        BBG = Form1.CreateGraphics
        BBG.DrawImage(BB, 0, 0, Form1.Width, Form1.Height)
        ' FIX OVERDRAW
        G.Clear(Color.Black)
    End Sub

    Sub CountTick()
        'Calculates the number of ticks per second the main loop is running at
        If tSec = TimeOfDay.Second AndAlso IsRunning = True Then
            tTicks = tTicks + 1
        Else
            MaxTicks = tTicks
            tTicks = 0
            tSec = TimeOfDay.Second
        End If
    End Sub
End Module

